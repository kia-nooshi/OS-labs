#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}


//Because we call exit with arbitrary value in user program
//Because we call exit with arbitrary value in user program
int sys_exit(void) {
    int status;
    
    if (argint(0, &status) < 0)
        return -1;

    exit(status);
    
    // Code execution will not reach here.
    return 0;
}

int sys_wait(void) {
    int *status;

    if (argptr(0, (char**)&status, sizeof(int*)) < 0)
        return -1;

    int result = wait(status);
    return result;
}
  //same as exit, use argptr instead of arg int 

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

int sys_hello(void)
{
  hello(); 
  return 0; 
}
// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int 
sys_waitpid(void)
{
  int pid, *status, options;

  // Get the process ID.
  if (argint(0, &pid) < 0)
    return -1;

  // Get the status pointer.
  if (argptr(1, (char**)&status, sizeof(int)) < 0)
    return -1;

  // Set default options.
  options = 0;

  // Call waitpid and return the result.
  int result = waitpid(pid, status, options);
  return result;
}